package com.parse.starter;

import android.app.Application;

import com.parse.Parse;

public class app extends Application {

     @Override
     public void onCreate() {
         super.onCreate();
         Parse.initialize(new Parse.Configuration.Builder(this)
                 .applicationId(getString(R.string.SPJlSyTN6k0eugklktrPRRZtvnHxwsDLuAK9lM6S))
                 .clientKey(getString(R.string.JZo67ozGIGkxmcMeOgOoqzTVoWKCFlWp04lfVhiH))
                 .server(getString(R.string.parseapi_back4app_com))
                 .build()

         );

     }
 }



